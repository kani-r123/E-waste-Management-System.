import { useEffect, useState } from "react";

const sections = ["Home", "E-Waste Guide", "Nearby Centres", "Collection Request", "Student Corner", "Login"];
const API_BASE = (import.meta.env.VITE_API_BASE_URL || "").replace(/\\/$/, "");

export default function App() {
  const [items, setItems] = useState([]);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [message, setMessage] = useState("Loading items...");
  const [requests, setRequests] = useState([]);
  const [requestForm, setRequestForm] = useState({ name: "", email: "", itemType: "Old mobile phone", quantity: 1, area: "Panvel" });
  const [requestMessage, setRequestMessage] = useState("Loading collection requests...");

  async function loadItems() {
    try {
      const response = await fetch(`${API_BASE}/api/items`);
      if (!response.ok) throw new Error("API request failed");
      setItems(await response.json());
      setMessage("");
    } catch {
      setMessage("Backend is not connected yet. Start Spring Boot, then refresh.");
    }
  }

  async function loadRequests() {
    try {
      const response = await fetch(`${API_BASE}/api/requests`);
      if (!response.ok) throw new Error("API request failed");
      setRequests(await response.json());
      setRequestMessage("");
    } catch {
      setRequestMessage("Could not load requests. Check that the backend is running.");
    }
  }

  useEffect(() => { loadItems(); loadRequests(); }, []);

  async function submitRequest(event) {
    event.preventDefault();
    setRequestMessage("Submitting request...");
    try {
      const response = await fetch(`${API_BASE}/api/requests`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...requestForm, quantity: Number(requestForm.quantity) })
      });
      if (!response.ok) {
        const detail = await response.text();
        throw new Error(detail || "Could not save request");
      }
      setRequestForm({ name: "", email: "", itemType: "Old mobile phone", quantity: 1, area: "Panvel" });
      setRequestMessage("Collection request saved successfully.");
      await loadRequests();
    } catch (error) {
      setRequestMessage("Request could not be saved. Check the backend connection and try again.");
    }
  }

  async function updateRequestStatus(id, status) {
    try {
      const response = await fetch(`${API_BASE}/api/requests/${id}/status`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status })
      });
      if (!response.ok) throw new Error("Update failed");
      await loadRequests();
    } catch {
      setRequestMessage("Status update failed. Check the backend connection.");
    }
  }

  async function addItem(event) {
    event.preventDefault();
    try {
      const response = await fetch(`${API_BASE}/api/items`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, description })
      });
      if (!response.ok) throw new Error("Could not save item");
      setName("");
      setDescription("");
      setMessage("Item saved.");
      await loadItems();
    } catch {
      setMessage("Could not save. Check that the backend is running.");
    }
  }

  async function deleteItem(id) {
    try {
      const response = await fetch(`${API_BASE}/api/items/${id}`, { method: "DELETE" });
      if (!response.ok) throw new Error("Delete failed");
      await loadItems();
    } catch {
      setMessage("Delete failed. Check the backend.");
    }
  }

  return (
    <div>
      <header className="top">
        <div className="wrap nav">
          <strong>Trash2Tech</strong>
          <nav>{sections.map(section => <a href={`#${section.toLowerCase().replaceAll(" ", "-")}`} key={section}>{section}</a>)}</nav>
        </div>
      </header>
      <main className="wrap">
        <section id="home" className="hero">
          <p className="eyebrow">RESPONSIBLE E-WASTE MANAGEMENT</p>
          <h1>Give electronic waste a better future.</h1>
          <p>A simple e-waste information website for students in Panvel.</p>
        </section>
        <section id="e-waste-guide">
          <h2>E-Waste Guide</h2>
          <div className="cards">
            {[
              ["Old Mobile Phone", "Do not throw old phones in household waste. Use an authorised collection or recycling centre."],
              ["Charger", "Keep damaged chargers separate and take them to an authorised e-waste collection point."],
              ["Battery", "Do not burn or dismantle batteries. Keep them safe and use an appropriate collection service."],
              ["Laptop", "Back up and remove personal data before sending an old laptop for recycling."]
            ].map(([title, text]) => <article className="card" key={title}><h3>{title}</h3><p>{text}</p></article>)}
          </div>
        </section>
        <section id="nearby-centres">
          <h2>Nearby Centres</h2>
          <article className="card"><h3>Authorised e-waste collection</h3><p>Check current authorised recyclers and local municipal guidance before visiting. Confirm location and opening hours directly.</p></article>
        </section>
        <section id="collection-request">
          <h2>E-Waste Collection Request</h2>
          <p>Submit an example request for responsible collection. Requests are stored through the Java API in the configured database.</p>
          <form onSubmit={submitRequest} className="form">
            <input value={requestForm.name} onChange={e => setRequestForm({ ...requestForm, name: e.target.value })} placeholder="Your name" required />
            <input type="email" value={requestForm.email} onChange={e => setRequestForm({ ...requestForm, email: e.target.value })} placeholder="Email (optional)" />
            <select value={requestForm.itemType} onChange={e => setRequestForm({ ...requestForm, itemType: e.target.value })} aria-label="E-waste type">
              <option>Old mobile phone</option><option>Charger</option><option>Battery</option><option>Laptop</option><option>Other electronics</option>
            </select>
            <input type="number" min="1" value={requestForm.quantity} onChange={e => setRequestForm({ ...requestForm, quantity: e.target.value })} aria-label="Quantity" required />
            <input value={requestForm.area} onChange={e => setRequestForm({ ...requestForm, area: e.target.value })} placeholder="Area (e.g. Panvel)" required />
            <button type="submit">Submit collection request</button>
          </form>
          <p role="status">{requestMessage}</p>
          <h3>Saved requests</h3>
          <div className="cards">
            {requests.map(request => <article className="card" key={request.id}>
              <h3>Request #{request.id}: {request.itemType}</h3>
              <p><strong>Name:</strong> {request.name}</p>
              <p><strong>Quantity:</strong> {request.quantity}</p>
              <p><strong>Area:</strong> {request.area}</p>
              <p><strong>Status:</strong> {request.status}</p>
              <button onClick={() => updateRequestStatus(request.id, request.status === "Pending" ? "Completed" : "Pending")}>
                Mark {request.status === "Pending" ? "Completed" : "Pending"}
              </button>
            </article>)}
          </div>
        </section>
        <section id="student-corner">
          <h2>Student Corner — Item Manager</h2>
          <p>This section demonstrates the React frontend connected to a Spring Boot CRUD API.</p>
          <form onSubmit={addItem} className="form">
            <input value={name} onChange={e => setName(e.target.value)} placeholder="Item name" required />
            <input value={description} onChange={e => setDescription(e.target.value)} placeholder="Description" />
            <button type="submit">Add item</button>
          </form>
          <p role="status">{message}</p>
          <div className="cards">
            {items.map(item => <article className="card" key={item.id}>
              <h3>{item.name}</h3><p>{item.description}</p>
              <button className="danger" onClick={() => deleteItem(item.id)}>Delete</button>
            </article>)}
          </div>
        </section>
        <section id="login">
          <h2>Login demonstration</h2>
          <p>Demo endpoint: POST <code>/api/auth/login</code>. Use the test credentials only in the classroom demo: <code>student</code> / <code>demo123</code>. This starter endpoint returns a token-shaped classroom demonstration value, not a secure signed JWT.</p>
        </section>
      </main>
      <footer><div className="wrap">© 2026 Trash2Tech · Responsible E-Waste Management</div></footer>
    </div>
  );
}
